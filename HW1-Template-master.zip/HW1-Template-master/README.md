#Homework #1

The instructions for each problem are included in the html. There are three problems, be sure to complete each one to the best of your ability.

##Built in Functions
There are two functions available for you to utilize inside `scripts.js`:
- `findMin()` takes six values as input and returns the minimum value
- `findGPA()` takes six variables as input and returns a GPA value

Take a look at both of these functions and try to understand how they work.
